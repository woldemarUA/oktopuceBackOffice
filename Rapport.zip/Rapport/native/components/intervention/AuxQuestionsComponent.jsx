import React, { useState, useEffect } from 'react';

import { View, Text } from 'react-native';

import { styles } from '../../Screens/styles/detailsStyles';

const AuxQuestionsComponent = ({ questions }) => {
  return (
    <View>
      <Text>AuxQuestionsComponent</Text>
    </View>
  );
};

export default AuxQuestionsComponent;
