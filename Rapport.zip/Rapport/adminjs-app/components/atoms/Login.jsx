import React from 'react';

const Login = () => {
  console.log('helloo');
  return <div>Login</div>;
};

export default Login;
