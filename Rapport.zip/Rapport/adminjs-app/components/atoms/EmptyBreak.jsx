import React from 'react';

const EmptyBreak = () => {
  return <div></div>;
};

export default EmptyBreak;
