import React, { useState, useEffect } from 'react';

const ListPropertyEquipmentSelectComponent = ({ record, property }) => {
  // console.log(record, property);
  return <div>ListPropertyEquipmentSelectComponent</div>;
};

export default ListPropertyEquipmentSelectComponent;
