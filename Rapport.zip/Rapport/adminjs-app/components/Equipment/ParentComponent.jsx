import React from 'react';

const ParentComponent = () => {
  const [options, setOptions] = useState([]);
  return <div>ParentComponent</div>;
};

export default ParentComponent;
