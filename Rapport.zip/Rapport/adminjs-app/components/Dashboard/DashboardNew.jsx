import React from 'react';

const DashboardNew = () => {
  return <div>DashboardNew</div>;
};

export default DashboardNew;
