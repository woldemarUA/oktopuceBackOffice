export const dashboardHandler = async () => {
  // Asynchronous code where you, e. g. fetch data from your database

  return { message: 'Hello World' };
};
